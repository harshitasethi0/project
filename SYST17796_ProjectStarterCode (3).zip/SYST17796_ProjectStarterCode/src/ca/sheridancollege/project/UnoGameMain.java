package ca.sheridancollege.project;

public class UnoGameMain {

    public static void main(String[] args) {
        // Create a new UNO game with a specified name
        UnoGame unoGame = new UnoGame("UNO Game");

        // Start the game
        unoGame.play();
    }
}
