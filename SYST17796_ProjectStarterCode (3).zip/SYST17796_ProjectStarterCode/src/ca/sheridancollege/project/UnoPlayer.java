package ca.sheridancollege.project;

public class UnoPlayer extends Player {

    public UnoPlayer(String name) {
        super(name);
    }

    @Override
    public void play() {
       
    }
}
